ace.define("ace/snippets/elm",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="elm"});                (function() {
                    ace.require(["ace/snippets/elm"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            