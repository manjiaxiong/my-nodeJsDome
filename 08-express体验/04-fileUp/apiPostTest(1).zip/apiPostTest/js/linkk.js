
(window.Mock11) ? '' : aa();
function aa() {
    function Mock11() {

    }
    window.Mock11 = Mock11;
}
